Upcoming version (not yet released)
===================================

Added
^^^^^

- Added the CPU-only D5 asynchronous latent runtime facade. It preserves the
  eight measured VAE bootstrap pairs, submits bounded raw 32-D latent planning,
  selects the execution-tick row, decodes it with current finite 99-D
  conditioning, and records state/latent history only after execution
  acknowledgement. The runtime checks originating request provenance and exact
  executor cleanup evidence. Stale, future, incompatible, exhausted and
  non-finite plans fail closed with no action. This integration evidence does
  not claim D5 timing, simulator, export, deployment or hardware readiness.

=========
Added
^^^^^

- Added the opt-in D4 sparse task surface on the D3 closed-loop seam. A new
  ``conditioned_continuation`` module wires the finished hard-keyframe
  inpainting and pose-cost guidance components into the frozen reference-free
  continuation through two narrow optional handover hooks; ``evaluate.py``
  gains ``--task-config PATH``, a strict bounded JSON loader under
  ``scripts/experiments/diffusion_d3_closed_loop/`` and a preparation tool that
  extracts verified sparse targets from an existing qualified recording. The
  default run, the eight bootstrap pairs, the measured current conditioning and
  the existing GUI/headless guards are unchanged.

- Added the bounded D3 reference-free X2 diffusion handover seam: owned eight-step state/latent history snapshots, active 167-channel no-mixture conditioning, strict 20-step DDIM/current-latent decoding, contract/hash guards, and an offline frozen D2/VAE replay diagnostic with explicit synthetic-conditioning and no-closed-loop claims. See ``docs/plans/beyondmimic_diffusion_d3_seam.md`` and the replay evaluator under ``scripts/experiments/diffusion_d3_replay/``.

- Added the bounded integration-only X2 closed-loop harness under
  ``scripts/experiments/diffusion_d3_closed_loop/``. Its explicit-path
  preflight loads the frozen contract, no-mixture projection, EMA-selected D2
  checkpoint, gravity VAE cohort member and manifest without constructing an
  environment; only ``--execute`` enters one matched 8-bootstrap/25-tick
  smoke budget. The report uses one bounded full/compact/marker persistence path,
  records actual imported-source versus artifact-root provenance and
  model/normalizer/file integrity, and makes no fake-test or simulator quality
  claim.

- Added the preregistered serial D3 pilot driver
  ``scripts/experiments/diffusion_d3_closed_loop/run_pilot.py``. It fixes the
  ``tennis_000`` seed x start-fraction matrix, the eight-bootstrap/tick budget
  and the deterministic baseline-boundary-safe horizon before any physics,
  runs one serial GPU environment at a time under a whole-batch wall/output
  cap, retains every attempted/partial/fall outcome, stops on software,
  integrity, output or untrusted-runtime failure, and records a manifest plus
  bounded JSONL progress. Its CPU fake tests cover the matrix, the horizon, the
  subprocess capture and the batch stop/continue policy.

- Added an opt-in single-branch Viser browser diagnostic for the D3
  frozen-policy path under
  ``scripts/experiments/diffusion_d3_closed_loop/view.py``. It reuses the
  evaluator's explicit-path frozen loaders and the existing Viser viewer, runs
  one operator-selected ``baseline`` or ``diffusion`` branch (eight real VAE
  bootstrap pairs then reference-free continuation), starts paused with
  pause/resume/single-step/slower playback, renders an explicit diagnostic-only
  status, and disables the stock reference-scrubbing controls. It is a separate
  authority from the unchanged matched-pair gate and makes no acceptance claim.

- Added the versioned X2 diffusion no-mixture representation contract
  ``mjlab-x2-state-latent-d1-no-mixtures-v1``: train-only normalization of 135
  physical hybrid-state values plus the frozen 32-D VAE latent (167-wide tokens,
  41 steps at 50 Hz). The explicit ``migrate-no-mixtures`` CLI rebuilds a
  derived dataset from legacy raw rows while preserving split assignments and
  source provenance; legacy projected bundles remain rejected.

- Added the X2 PPO tracking task ``Mjlab-Tracking-Flat-AgiBot-X2-No-State-Estimation-Increated-Perturbations``. It preserves the standing-start X2 task while using the Unitree G1 magnitudes for initial pose/velocity/joint-position randomization and external pushes.

 and evaluator at
  ``scripts/experiments/vae_teacher_student_replay/``. It replays a frozen
  teacher and VAE student on the same recorded 164-D teacher/68-D reference
  and 99-D conditioning states, reports raw-action/target disagreement by
  fixed reference-time windows, validates embedded reference and student
  ONNX parity, and deliberately makes no closed-loop stability claim. The
  compact 1,103-state failure/success fixture and source/model hashes are in
  ``tests/fixtures/vae_teacher_student/``.

- Added an offline X2 tennis reference generator that copies clips 000–020
  (012 is absent) into ``data/tennis/guard040_linear05/`` with 0.5-second
  linear root-position/joint transitions to motion 040's initial guard pose,
  yaw-aligned per endpoint, SLERP root rotation and FK-derived body poses.
  `scripts/render_x2_tennis_guard_gifs.py` renders each clip and the 20-clip
  entry/exit comparison as GIFs.
  Original reference files and frozen teacher assets remain unchanged;
  reference generation does not validate balance or permit using existing
  teachers against changed motion hashes. An offline MuJoCo renderer
  generates one annotated GIF per clip that plays at real time, plus a 20-clip
  transition comparison (2x slow) under `data/tennis/guard040_linear05/renders/`;
  these are kinematic previews, not controller or balance rollouts.

- Added the D1 diffusion integration CLI (`diffusion`) with fail-closed frozen
  artifact preflight, explicit bounded collection via a concrete runtime
  factory, grouped window indexing, train-only statistics persistence, shard
  inspection, and offline action/latent replay diagnostics. Help and offline
  commands do not construct an environment; collection requires `--execute`
  and cannot override the immutable D0 execution record. See
  `docs/plans/beyondmimic_diffusion_d1_implementation.md`.
- Added the non-authorizing 50 Hz collection input at
  `configs/diffusion/x2_50hz_collection.yaml`.

- Added opt-in phase-balanced within-motion replay sampling for the shared
  cohort path. ``distill train --teacher-ids ... --phase-bins N`` (default 0,
  disabled) splits each clip's reference-phase axis into ``N`` cells and
  equalizes every minibatch's within-motion exposure over the clip's non-empty
  cells, correcting retained-row density skew (long-surviving clip segments
  accumulate more replay rows than hard-to-reach phases) without changing the
  configured across-motion mixture. The default keeps the historical
  density-proportional draw bit-for-bit. Balancing is coverage-only: it cannot
  invent coverage for phases never collected and stays difficulty-blind
  (adaptive, loss-aware sampling remains refused on the multi-motion path).
  ``phase_bins`` is recorded in the resolved configuration
  (``replay.phase_bins``) and must be reproduced on resume, with checkpoints
  that predate the option resuming at the documented default 0; the
  single-teacher path refuses the flag. Per-phase telemetry
  (``retained_by_phase_bin``/``drawn_by_phase_bin``) is added to replay reports
  when enabled. See ``docs/source/x2_tennis_distillation.rst``.
- Added opt-in standing-start distillation for the shared cohort path. Real
  deployment engages from standing, whereas reference-frame-only initialization
  never trains or validates that transition. ``distill train`` accepts
  ``--reset-policy standing-mixture`` with configurable
  ``--standing-start-fraction`` (default ``0.25``),
  ``--standing-start-window-frames`` (default ``25``), and
  ``--standing-start-frame-zero-fraction`` (default ``0.5``); the reference
  policy remains the exact default. A singleton cohort uses the Python-literal
  spelling ``--teacher-ids "('tennis_000',)"``. Standing resets use a
  clip-local ``min(25, F_i)`` window and report the realized frame-zero rate
  ``a + (1-a)/W_i`` rather than treating ``a`` as that rate. Fractions are
  proposed starting hyperparameters, not tuned values. Teacher qualification is
  deliberately a manual standalone activity and is not a pipeline gate.
  Student-only ``standing-start`` and ``standing-window`` evaluation profiles
  retain explicit censoring and completed-or-failed denominators. Enabled runs
  use version-3 cohort checkpoints; version-2 reference-only runs remain
  unchanged and cannot be resumed with standing enabled. This work is
  simulation-only and makes no policy-quality, sim2sim, or hardware claim. See
  ``docs/source/x2_tennis_distillation.rst``.

- Added version-3 cohort export. ``distill export --asset-audits`` exports a
  saved version-2/3 M4 cohort checkpoint as one shared student graph pair
  stamped with the cohort identity plus one ``{contract, motion, parity}``
  triple per manifest member in manifest order (the order the deployed
  controller plays them in). Each member is audited by the existing
  ``make_export_audit`` producer against a pinned single-teacher environment of
  that member; audits that describe different compiled robots are refused, and
  a cohort checkpoint with the singular ``--asset-audit`` is refused rather
  than silently reduced to one teacher. Member contracts stay version-2 shaped
  so the C++ deployment parser is unchanged. See
  ``docs/source/x2_vae_export_contract.rst``.

- Added the M4 shared multi-teacher distillation cohort. ``distill train
  --teacher-ids "('tennis_000','tennis_001')"`` trains **one shared conditional
  VAE** over both 50 Hz tennis clips in **one** vectorized simulator: rows keep
  their own reference clip and are labeled by that clip's frozen teacher through
  one frozen teacher bank, actions/observations keep their meanings, and the
  gravity schema (68/99/32/31) is unchanged. Motion and teacher ids stay routing
  metadata and never enter decoder conditioning. Selection is explicit and
  mutually exclusive with the preserved single-teacher ``--teacher-id`` path
  (supplying both is refused before any environment is constructed), and
  omitting both keeps the historical ``tennis_000`` default. Cohort runs use
  stratified fixed environment slots (deterministic largest-remainder allocation
  from the manifest weights, at least one row per selected motion, seeded row
  permutation), uniform phase sampling recorded as an explicit private override,
  and one per-motion balanced replay that cannot let a shorter or easier clip
  evict another. Unknown or repeated teacher ids and an impossible replay
  capacity are refused before any environment is constructed, and a failure
  after the environment exists closes it exactly once. See
  ``docs/source/x2_tennis_distillation.rst``.

- Added version-2 M4 cohort checkpoints, strict cohort resume, and checked
  member selection. ``distill train`` records the ordered member identities with
  every artifact path and digest, per-clip extent/source digest/audited body
  mapping, the ordered mapping digest, the common action/control/observation
  contract, the slot and phase policy, the replay partition policy, resource
  settings, and all RNG state; strict resume reproduces the whole record and
  only the total iteration budget and the save/reporting cadence may differ. A
  version-2 checkpoint is never converted to or from version 1, resume restarts
  the simulator with a segment namespace above every retained replay partition,
  and ``distill evaluate``/``distill play`` accept a single **member** of the
  saved cohort (member artifacts and the common contract validated against the
  live manifest, the full stored cohort identity kept in the report). The
  Viser Checkpoints tab dispatches each discovered artifact to its version's
  loader. Version-1 training resume, inference, playback, and export are
  unchanged.

- Added ``distill evaluate-cohort``: a bounded evaluation that normalizes
  ``--teacher-ids`` into manifest order (repeated ids refused before any
  environment is constructed), pins each selected motion into its own
  single-motion environment, and builds a fresh identically seeded adapter for
  each mode so the student baseline never inherits the teacher rollout's
  simulator state; one student model is loaded once and reused. Each motion
  block reports, separately for the teacher baseline and the shared student, the
  segment and outcome counts, completion/failure denominators, censored-segment
  counts, reference coverage, timeout/step-cap/timer censoring, disaggregation,
  and action-rate metrics with the same seed, phase mode, environment count, and
  step cap. Every reported level is attributed to the motion's cohort identity
  (the stored cohort member's motion id and teacher code, or the explicit
  manifest position for a teacher-only run) rather than to the pinned
  environment's local clip 0, and each block records which source it used.
  Aggregate summaries report an equal-motion ``macro`` view and an explicitly
  ``clip_duration_weighted`` view (weights proportional to ``frames/fps``) with
  the per-motion values, aggregation weights, contributing motion counts, and
  partially covered metrics retained; execution errors are reported per motion
  and mode, make ``complete`` false, and the report states that no aggregate is
  a quality pass.

- Added ``distill train`` reporting of per-motion collection attribution
  (``collection.motion_stats``: per-motion samples, teacher/student steps,
  boundaries, teacher/student disagreement, and reference-frame coverage)
  alongside the existing totals and boundary summary.

- Added the audited ``distill export`` VAE deployment seam. Version-2 bundles
  contain matching encoder/decoder ONNX graphs, frozen exact normalizers, a
  frame-major float32 motion table, full-precision action metadata, explicit
  sensor/anchor provenance, relative paths, and SHA-256 content identities.
  Export refuses malformed source/schema data and refuses to manufacture
  physical evidence from ``declared_unverified`` tensor metadata. See
  ``docs/source/x2_vae_export_contract.rst``.


- Added ``distill play``: interactive playback of a checkpointed distillation
  student in the existing Viser (default) or native viewers. It reuses the
  audited evaluation environment contract (no ``play=True`` overrides, explicit
  ``--sampling-mode {start,uniform}``), loads the checkpoint model-only before
  building the simulator, packs with the checkpoint's saved schema, performs one
  audited seeded reset before the first viewer action, and decodes the
  deterministic mean latent with no trainer, optimizer, replay buffer, or PPO
  runner. The Viser Checkpoints tab discovers ``checkpoint-iter-<N>.pt`` and
  ``checkpoint-final.pt`` and validates every load, refusing an incompatible
  swap. See ``docs/source/x2_tennis_distillation.rst``.

- Added the bounded M3 native single-teacher distillation lifecycle: segment-aware
  collection, pure VAE updates, atomic checkpoint/resume, and ``distill train`` /
  ``distill evaluate`` commands for the existing 50 Hz X2 ``tennis_000`` contract.
  The commands record resource/configuration provenance and distinguish bounded
  implementation smoke evidence from policy quality and hardware readiness; they
  do not launch unbounded production training or student export.

- Added periodic checkpointing to ``distill train`` through
  ``--checkpoint-every N``. The default cadence is 500 completed iterations;
  ``0`` disables periodic saves. Positive ``N`` writes an atomic
  ``checkpoint-iter-<lifetime iteration>.pt`` after every ``N`` completed
  iterations, each one a complete resume input, and reports every checkpoint
  written by the invocation. The cadence is recorded in the checkpoint's
  ``resolved_config`` for audit only and is not a resume invariant, so changing
  it never refuses a resume and a resumed run continues the lifetime filename
  sequence. Training now defaults to ``logs/distillation/<task-id>/`` when
  ``--task-id`` is supplied, or a UTC timestamp directory below
  ``logs/distillation/`` otherwise.

- Added progress reporting to ``distill train`` through ``--progress-every N``.
  The default cadence is 10 completed iterations; ``0`` disables it. A positive
  ``N`` writes a flushed ``[progress]`` line to stderr every ``N`` completed
  iterations with the lifetime iteration, collected samples, last update loss,
  disagreement, elapsed time, measured seconds per iteration, and projected
  ETA. Progress is written to stderr so stdout remains exactly the
  machine-readable JSON report; launchers can capture stderr as ``train.log``.

- Added model-only student evaluation to the M3 distillation CLI. ``distill
  evaluate --mode student --checkpoint PATH`` reconstructs the saved model via
  the new ``InferenceModel``/``load_inference_checkpoint`` API exported from
  ``mjlab.tasks.tracking.distillation``, infers the saved schema and model
  settings, and validates teacher hashes, control contract, and weight
  shape/dtype/finiteness without requiring the checkpoint's optimizer, replay
  buffer, training batch settings, or collector RNG. ``train`` and ``evaluate``
  now also report the requested seed, the resolved seed the environment factory
  applied before startup randomization, and the complete resolved
  runner/trainer/runtime configuration that is stored in the checkpoint.

- Documented specialist versus general tracking teachers, multimodal control,
  and the role of latent diffusion in
  ``docs/plans/beyondmimic_general_tracker_and_diffusion.md``. The discussion
  retains specialist supervision for the current experiment and does not
  authorize new training.

- Added the M2 gravity-first latent policy core for BeyondMimic distillation:
  versioned named observation schemas (68/99/32/31 by default, with explicit
  102/105 anchor ablation layouts), pure packing, separate explicit student
  normalizers, conditional VAE mean/sampled inference, exact reconstruction/KL
  loss, and bounded raw labeled replay. The core is CPU-testable and does not
  add simulator collection, DAgger, training, rollout, or student export;
  physical sensor frames and validated cohort joint order remain caller-owned
  future work. See ``docs/source/x2_tennis_distillation.rst``.

- Added the first milestone of the BeyondMimic-style VAE distillation work: a
  typed, versioned teacher manifest (``configs/distillation/x2_tennis.yaml``)
  with compatibility validation, a frozen actor-only ``FrozenTeacher``/
  ``TeacherBank`` with per-teacher checkpoint normalizers and deterministic
  batched routing, and a first-class CPU ``uv run distill validate-teachers``
  command that checks native actions against the original ONNX exports for both
  selected 50 Hz X2 tennis teachers (plus export/checkpoint association and
  embedded reference arrays). The safe saved-configuration loader used by
  ``load_saved_lookahead_s`` moved to ``mjlab.utils.os.load_saved_yaml`` and now
  keeps ``!!python/name`` callables as qualified-name strings; training,
  collection, and student export are later milestones. See
  ``docs/source/x2_tennis_distillation.rst``.

- Added the X2 tennis-end recovery fine-tuning task
  ``Mjlab-Velocity-Flat-AgiBot-X2-No-State-Estimation-Tennis-Recovery``, an
  opt-in variant of the X2 no-state-estimation velocity task that pairs a
  full-state recovery reset event (80% of environments) with zero-velocity
  commands, while retention environments (20%) keep the original reset
  sequence and command distribution. The task loads tennis endpoint states
  from ``data/tennis/*.npz``, restores joint positions/velocities, pelvis
  world pose and world-frame linear/angular velocity, and recenters XY to the
  environment origin while preserving reference height. The source velocity
  checkpoint (``model_19999.pt``) loads strictly via the narrow
  ``TennisRecoveryOnPolicyRunner`` with optional post-load LR override
  (``initial_finetune_lr``). A bounded evaluation CLI provides deterministic
  held-out row selection for source-vs-candidate comparison. See
  ``docs/source/x2_tennis_recovery.rst``.

- Added the X2 velocity torso-IMU ablation grid: four tasks derived from
  ``Mjlab-Velocity-Flat-AgiBot-X2-No-State-Estimation`` that move the actor onto
  the torso ``imu_1`` gyro and up-vector and enumerate the two frames the
  privileged critic can read — ``-Torso-IMU-Critic-Pelvis-Root``,
  ``-Torso-IMU-Critic-Pelvis-Upvector``, ``-Torso-IMU-Critic-Torso-Root`` and
  ``-Torso-IMU-Critic-Torso-Upvector``. Observation order and widths, rewards,
  terminations, actions, commands, domain randomization, terrain and PPO settings
  are unchanged, each variant has its own PPO directory, and the shipped task is
  untouched, so the four are fresh runs comparable against it. The twist command
  and its velocity rewards are root-referenced while ``upright`` and
  ``body_ang_vel`` are torso-referenced, so a torso actor trades root-frame rate
  observability against directly measuring what is penalized. See
  ``docs/source/sim2real_domain_randomization.md``.

- Added the X2 torso-IMU ablation
  ``Mjlab-Tracking-Flat-AgiBot-X2-No-State-Estimation-Correlated-DR-Reduced-Perturbations-Torso-IMU``,
  the reduced-perturbation baseline with the anchor still on ``torso_link`` but
  the ``base_ang_vel`` observations (actor and critic) and the critic's
  ``base_lin_vel`` re-pointed from the pelvis ``imu_0`` site to the torso
  ``imu_1`` site. The observation order, widths, noise, scale, delay, all DR
  axes, rewards, terminations, reset/push bounds and PPO settings are unchanged,
  and the root stays the pelvis; only the IMU source moves, so it is a clean A/B
  against the baseline and requires fresh training in its own PPO directory. The
  ONNX export metadata now also records the per-term sensor site and body so the
  angular-velocity frame is explicit. See
  ``docs/source/sim2real_domain_randomization.md``.

- Added the X2 anchor ablation
  ``Mjlab-Tracking-Flat-AgiBot-X2-No-State-Estimation-Correlated-DR-Reduced-Perturbations-Pelvis-Anchor``,
  the reduced-perturbation baseline with ``commands.motion.anchor-body-name``
  set to ``pelvis`` (the simulated root and the frame the robot measures
  directly) instead of ``torso_link``. Rewards, terminations, DR, reset and push
  bounds, PPO settings, critic terms and observation dimensions are unchanged,
  so it trains from scratch in its own PPO experiment directory. See
  ``docs/source/sim2real_domain_randomization.md``.

- Added three additive X2 tracking observation ablations from the selected
  reduced-perturbation ABLATION3 baseline:
  ``...-Projected-Gravity`` (161 actor dimensions),
  ``...-Projected-Gravity-And-Anchor`` (167), and
  ``...-Vendor-Velocity-Scaling`` (164 with measured gyro/joint-velocity
  preprocessing scales). They use separate PPO experiment directories,
  preserve the historical tasks and checkpoint, and require fresh training.
  See ``docs/source/sim2real_domain_randomization.md`` for contracts,
  normalization and future deployment caveats.
- Added the X2 no-state-estimation tracking ablations
  ``Mjlab-Tracking-Flat-AgiBot-X2-No-State-Estimation-Correlated-DR`` and
  ``Mjlab-Tracking-Flat-AgiBot-X2-No-State-Estimation-Correlated-DR-Reduced-Perturbations``.
  The first correlates Kp/Kd reset scales and joint encoder packet delay; the
  second halves only reset/push perturbation bounds and lengthens push intervals.
  They use independent PPO experiment directories and leave the existing X2
  baseline task and its checkpoints unchanged. See
  ``docs/source/sim2real_domain_randomization.md``.

- The motion-tracking tasks randomize the actuator PD gains (``dr.pd_gains``)
  per episode with matched ``kp_range``/``kd_range`` of ``(0.7, 1.3)`` in
  ``scale`` mode, so policies train against a spread of joint servo stiffness
  and damping for actuator sim-to-real robustness.

- The motion-tracking tasks randomize seven more sim-to-real axes by default:
  link mass/inertia/COM (``dr.pseudo_inertia``), joint armature, actuator effort
  limits (weaker-only, with an extra 0.45x range on the X2 wrist group, which the
  vendor simulator clamps to 2.2 N.m against the URDF's 4.8), joint friction and
  damping, foot geom size, and observation delay. X2 actuator groups also carry a
  0-2 step command delay. ``MJLAB_DR_AXES`` selects a subset at process start so a
  trained checkpoint's sensitivity can be swept one axis at a time (``none``
  reproduces the pre-axis set); unknown names raise. See
  ``docs/source/sim2real_domain_randomization.md``.

- AgiBot X2 Ultra (flagship revision, vendor URDF release v1.3.0) joins the asset
  zoo as ``get_x2_robot_cfg``, together with the motion-tracking tasks
  ``Mjlab-Tracking-Flat-AgiBot-X2`` and its no-state-estimation variant. Actuator
  parameters are derived from AgiBot's PFP joint-module data (rotor inertia and
  reducer ratio) and the peak joint torques of the flagship revision, and
  ``scripts/convert_agibot_x2_to_mjcf.py`` ports a vendor release into an
  mjlab-convention MJCF (URDF body inertials, named collision geoms, mjlab IMU
  sensor names).
- AgiBot X2 Ultra gains a flat-terrain velocity-tracking task
  ``Mjlab-Velocity-Flat-AgiBot-X2-No-State-Estimation`` (no-state-estimation
  variant only: the actor observes gyro, IMU up-vector, encoders and the twist
  command, but not base linear velocity; the critic keeps it privileged). The
  config injects ``left_foot``/``right_foot`` sites at spec build time for the
  foot height scan and foot slip/clearance rewards, leaving the vendored XML
  byte-identical. It also randomizes the actuator PD gains per episode
  (``dr.pd_gains``, matched ``kp_range``/``kd_range`` of ``(0.7, 1.3)`` in
  ``scale`` mode) on top of the base velocity DR set; command-channel delay is
  inherited from the X2 actuator groups.
- New script ``scripts/record_tracking_policy_commands.py`` records the motor commands
  a tracking checkpoint issues in the training simulator: for every actuated joint it
  logs the reference frame's joint state, the actor observation, the raw and clipped
  actions, the processed position target, the simulator target, pre/post joint state,
  actuator torque, root state, gains, effort limits and timing, plus provenance and a
  nominal-diagnostic override list. It supports an optional deploy-ONNX parity check on
  identical actor inputs and refuses to overwrite an existing recording. See
  ``docs/tracking_policy_command_recording.md``.
- Motion-tracking policies can optionally receive a single future reference frame
  through ``MotionCommandCfg.lookahead_s``.
- The G1 29DOF mode-15 tracking task adds dedicated foot-tracking reward terms
  (``motion_feet_pos``, ``motion_feet_lin_vel``) that grade ankle position and
  swing velocity directly instead of diluting them in the all-bodies mean.
- Tracking task init-frame sampling gains a ``weighted`` mode: with
  ``MotionCommandCfg.init_weight_s > 0``, episode start frames are drawn from
  an exponential distribution over the trajectory (``p(t) ∝ exp(-t/τ)``),
  concentrating training on the beginning of the motion.
- New script ``scripts/evaluate_tracking_policy.py`` evaluates a tracking
  checkpoint against a local motion file without Weights & Biases, reporting
  MPKPE, joint velocity error, end-effector errors, success rate and a
  termination-time histogram over the full trajectory.
- New script ``scripts/retarget_npz_to_tracking_npz.py`` converts a retargeted
  qpos motion (e.g. UMR / SMPL-X retargeting output: ``qpos``, ``fps``,
  ``robot_joint_names``) into the tracking-format npz consumed by ``train.py``.
  It resamples the trajectory to the environment rate (50 Hz by default) and
  replays it kinematically through the G1 29DOF mode-15 robot.

Changed
^^^^^^^

- The D4 task loader now re-verifies recording-bound sources instead of trusting
  the declared label: it re-reads the recording and summary bytes, re-checks their
  digests, rows, recorded contract identity and member/seed/start-frame scenario,
  and re-extracts every target state at its tick before accepting the task. A
  hand-written ``preparation_tool:`` prefix can no longer upgrade a source, an
  unverified or merely declared source is refused under ``--execute``, and the
  task file plus its bound recording files join the run's before/after integrity
  expectations. The preparation tool gained ``--recording-dir`` for actual D3
  closed-loop runs (the archived ``diffusion-d3-recorded-comparison-*`` layout),
  keeps raw NPZ shards as an honestly ``declared`` weaker layout, and validates
  its payload with the strict loader before an atomic write. Task configs and
  recording files are read through a bounded regular-file reader.

- The opt-in D4 sparse task surface now enforces pure modes (hard keyframes only
  in ``keyframe``, soft pose goals only in ``poseguided``, both in ``combined``)
  and refuses a hard keyframe and a soft goal scheduled on the same tick, since
  the hard row makes the soft cost a constant with zero gradient.

- D4 task runs now score hard keyframes and soft pose goals separately from
  trusted measured observations, including the final budget post and a
  trustworthy fall post, which are reported through a new optional
  post-observation seam. Planning ticks and measured observations are counted
  separately, a next-row metric on a hard-fixed row is labelled
  ``hard_keyframe_row`` instead of ``denoiser_forecast``, and
  ``TaskConditioning.reset()`` plus the new optional reset hook clear the whole
  task ledger before the mandatory fresh bootstrap. Runs without
  ``--task-config`` keep the original D3 provenance: no task block is emitted in
  the preflight report, the run provenance or the bounded marker.

- The D3 reference-free continuation seam accepts two optional D4 task hooks
  (``plan_transform`` and ``sampler_factory``) plus an optional bounded per-step
  task record on ``ContinuationStep``. Both default to ``None``, so every
  existing caller keeps the original plan, sampler, RNG and decode path.

- The D3 reference-free continuation seam also accepts two optional reporting
  lifecycle hooks (``on_reset`` and ``measured_post``). The reset hook runs after
  the seam clears its own history, and the measured-post seam only forwards an
  already-validated trusted successor tick; neither can sample, decode, change
  history or advance the planning count. Both default to ``None``.

- The D3 closed-loop matched-pair runner now defaults its initial/bootstrap
  array matching tolerance to ``1e-3``, the teacher-tracking error scale
  selected by the user, instead of ``1e-6``. This is a raw matched-array
  tolerance, not a universal length unit and not an unguided reference-tracking
  failure criterion; historical ``1e-6`` results remain unchanged.

- ``distill train`` now exposes standing-start options without changing the
  legacy reference-only default. Standing options require the cohort path,
  including the singleton tuple form, and their resolved reset provenance is
  persisted only in version-3 standing cohort checkpoints. ``distill evaluate``
  and ``distill evaluate-cohort`` accept the student-only
  ``--reset-profile standing-start|standing-window`` profiles; explicit
  ``--sampling-mode`` is not combined with these profiles. Teacher and both-mode
  transition evaluations remain intentionally unsupported.

- ``distill train --teacher-id`` now defaults to ``None`` so the plural
  ``--teacher-ids`` selection can be unambiguously distinguished from it. The
  resolved behavior is unchanged: with neither flag the single-teacher path uses
  ``tennis_000`` exactly as before, and ``--teacher-id <id>`` behaves as before.
  Because the shared Tyro configuration uses Python literal syntax for
  collections, the plural form is ``--teacher-ids "('a','b')"`` (a single
  element keeps its trailing comma). ``distill export`` refuses a version-2 M4
  cohort checkpoint explicitly instead of fabricating a single-teacher training
  history; version-1 export is unchanged.

Fixed
^^^^^

- Viser motion scrubbing now aligns the first policy action after ``Start Here``
  (or a paused frame-slider move) with the edited command state. The
  observation cache is refreshed through a scoped
  ``ObservationManager.refresh(env_ids, baseline=...)`` hook that splices the
  recomputed rows for the edited environments only, so unedited environments
  keep their cached rows and their history/delay timelines (no extra tick or lag
  draw). ``Start Here`` captures the environment/frame/selection at click time
  and snapshots the pre-reset cache with
  ``ObservationManager.cached_observations()``, so a partial reset cannot leak
  its whole-batch recompute (and resampled raw noise) into the untouched
  environments; the all-env path refreshes everyone normally. The frame write
  and refresh are queued to the viewer's main loop instead of running on Viser's
  GUI worker thread, and a rejected checkpoint swap keeps the viewer alive
  without installing the returned policy (a loader that mutates captured state
  in place is not rolled back).

- ``load_inference_checkpoint`` now accepts a relocated, byte-identical
  reference motion: a changed ``control_contract['motion']`` path is allowed
  only when the supplied teacher hashes (including the motion digest) match and
  every other contract field agrees. Strict training resume is unchanged.

- ``distill evaluate --mode student`` can now load a checkpoint produced by
  ``distill train``. It previously rebuilt a default student and a
  training-shaped trainer/replay, so loading a train-produced checkpoint failed
  on the saved trainer configuration and then, even with matching settings, on
  the saved collector RNG.

- ``play.py`` and ``evaluate.py`` now restore ``lookahead_s`` from the saved
  ``params/env.yaml``, so watching or evaluating a checkpoint trained with
  lookahead works without manually repeating the flag. The saved YAML uses
  Python-specific tags (``!!python/tuple``), which are now parsed safely.
- The deployment ONNX exporter now reconstructs the saved lookahead setting and
  can convert a state-estimation tracking checkpoint to the no-state-estimation
  observation layout required by the G1 deployment controller.

Changed
^^^^^^^

- ``distill train`` reports no longer embed the per-environment boundary
  arrays. Each iteration's ``collection.boundaries`` is now a compact summary
  by default: per-``reason`` boundary-record and environment-mention counts,
  the observed before/after segment and generation ranges, and the iteration's
  ``ticks``/``records``/``env_mentions`` totals. A boundary record holds four
  full-batch arrays (before/after segment and generation) plus ``env_indices``,
  so a 4096-environment, 20-iteration ``train-report.json`` reached 211 MB and
  the raw arrays are now written only on request with the new
  ``--report-boundaries full`` flag (``summary`` is the default, and an unknown
  value is refused before any environment is constructed). A summary report is
  aggregated per iteration as collection finishes instead of buffering the
  whole run, and every other report entry is unchanged.

- ``distill evaluate`` no longer accepts the trainer-only options
  ``--learning-rate``, ``--beta``, ``--accumulation-steps``,
  ``--minibatch-size`` and ``--replay-capacity``; student evaluation is
  model-only and infers those settings from the checkpoint, so keeping the flags
  would have silently ignored them.

- ``distill train``/``evaluate`` forward ``--seed`` into environment
  construction, so the private environment configuration is seeded before MuJoCo
  startup randomization instead of relying on a post-construction global seed.
  A resume now compares the checkpoint's stored ``resolved_config`` provenance
  against the requested settings and refuses a mismatch, while still allowing
  the explicitly requested total-budget extension of ``--max-iterations``.

- The AgiBot X2 tracking task now tracks the full wrist chain: the body-tracking
  rewards previously supervised ``left/right_wrist_yaw_link`` only, so wrist
  pitch/roll had no reward gradient and stayed passive regardless of reference
  motion. ``body_names`` now also includes ``left/right_wrist_pitch_link`` and
  ``left/right_wrist_roll_link``, and the four body-tracking reward terms
  gained an optional per-body ``body_weights`` parameter; the X2 task uses it
  to grade wrist pitch/roll at 0.3 vs 1.0 for the main body chain, so wrist
  flexion is reproduced without competing with core pose/velocity tracking.

- ``scripts/retarget_npz_to_tracking_npz.py`` takes a ``--task`` argument instead of
  hard-coding the G1 29DOF mode-15 environment, so a retargeted motion can be replayed
  onto any registered tracking robot.
- Bumped ``rsl-rl-lib`` from 5.4.2 to 5.5.0. This update removes the ``logger_type``
  attribute of the ``rsl_rl.utils.Logger``, so code that previously checked
  ``logger.logger_type`` must instead check the type of ``logger.writer``.
- The AgiBot X2 actuator gains are now the gains the real robot commands in its
  native stable stand, measured from the recorded ``/aima/hal/joint/*/command``
  messages of two hardware captures, instead of the reflected-inertia 10 Hz
  template. The hips, knee, ankles, arms and head yaw move to the measured
  values (hip 100/4, knee 150/5, ankle pitch 40/3, wrist pitch/roll 20/1,
  head yaw 3.4/0.114, ...). Relative to the template these are 1.7x softer on the
  hips and 2-6x stiffer on the ankles, elbow, wrist and head yaw. Waist yaw and
  waist pitch/roll keep the template value because the vendor's own two tables
  disagree by 3.75x and 7.5x on them; head pitch keeps it because the measured
  gain contradicts the joint's 0.6 N.m effort limit.

  See ``docs/source/x2_gain_provenance.md`` for the measurement chain, the four
  other vendor gain tables in circulation, and the open evidence gaps (notably:
  the gains are *commanded*, and nothing yet verifies the motor-side loop).
- The X2 action scale is no longer ``0.25 * effort_limit / Kp``. It is now the
  larger of that torque floor and a tracking floor derived from the reference
  motion's p95 deviation from the keyframe, so a joint's gain and its action
  parameterization are no longer coupled. This raises the action scale on six
  groups, where a unit action consequently reaches 27-60% of the torque budget
  (knee 33%, elbow 50%, wrist pitch/roll 60%); the other ten sit at exactly 25%.
- The X2 keyframe is the pose the real robot is measured standing in (hip pitch
  -0.19, knee 0.457, ankle pitch -0.267, shoulder pitch 0.4, elbow -1.2) instead
  of an ad hoc bend, with the soles still flat on the ground. Both X2 tasks share
  the keyframe, so the velocity task's default pose and its action scales (which
  come from the same robot-level table) change with it; its actor and rewards are
  otherwise untouched.
- The tracking tasks' sim-to-real randomization ranges are capped at 5% of
  nominal. The axes they carry exist nowhere else (the velocity tasks randomize
  only the actuator PD gains), so they were the only place a policy could be
  trained against an actuator markedly different from the one it runs on: the
  armature and joint-friction scales go from +-30% and +-50% to +-5%, the effort
  limits from 0.75-1.0x to 0.95-1.0x, and the pseudo-inertia mass range from
  0.90-1.10x to 0.95-1.05x with its COM shift halved to +-1 cm. Two ranges have
  no nominal to take 5% of and are documented rather than scaled: the absolute
  passive-damping range is one tenth of what it was (0.03 N.m.s/rad on a leg
  joint, now all but inert against a derivative gain of 4), and the discrete
  0-1 step observation delay is unchanged. The X2 wrist effort derating drops to
  its 5% residual, which means the vendor simulator's 2.2 N.m wrist clamp is no
  longer trained for; modelling it now requires changing the nominal wrist
  effort limit instead.
- The X2 waist yaw actuator moves to the measured hardware gain (``kp 40``, ``kd 8``,
  from 170.785/10.872) and to the reflected rotor inertia AgiBot's own Isaac actuator
  config carries for it (0.010177520, from the 0.043260 the PFP-96 torque class
  implied). The measured value had been held back because the vendor's own two tables
  disagree 3.75x on that joint (40/8 standing, 150/3 posture hold); a third source
  resolves it, since the vendor's sample policy ships 40.1792/2.5579, which is the
  10 Hz template applied to that armature. The X2 effort limits are now pinned by a
  test to the flagship revision's released joint ratings: the package this differs
  from (`sonic-x2`) is built on the newer revision, whose waist is 36 N.m and wrist 6
  rather than 48 and 4.8. See ``docs/source/x2_gain_provenance.md`` §7.

Fixed
^^^^^

- Capped ``wandb`` below 0.29, which removed the ``start_method`` setting still passed
  by ``rsl-rl-lib`` and crashed training runs launched with ``--logger wandb``.
- ``distribution="gaussian"`` domain randomization now draws an independent value per
  environment. ``sample_gaussian`` ignored its ``size`` argument when ``mean``/``std``
  were tensors, so every environment received the same sample :issue:`1168`.
- ``FlatPatchSamplingCfg(patch_radius=0)`` no longer collapses every patch to the
  sub-terrain center. The edge-exclusion mask sliced ``arr[-0:]``, which is
  ``arr[0:]``, so it cleared the entire valid mask :issue:`1171`.
- The X2 joints no longer inherit the vendored MJCF's blanket
  ``frictionloss="0.3"``: dry friction is now per joint group, at or below 2% of
  each joint's rated torque. The old value was 50% of ``head_pitch``'s effort
  limit, and combined with the friction and effort-limit randomization it could
  reach the joint's whole torque budget and lock it.
- The X2 tracking task's joint-damping randomization is no longer an absolute
  ``(0.0, 0.3) N.m.s/rad`` range for every joint. It scales with each group's
  torque class (``effort_limit / 400``, which reproduces the old value for the
  legs), because on ``head_pitch`` that absolute range was 37% of the joint's
  own derivative-gain authority.


Version 1.6.0 (August 8, 2026)
------------------------------

.. admonition:: Breaking API changes
   :class: attention

   - ``CollisionCfg`` now requires ``contype``, ``conaffinity``, ``condim``,
     and ``priority`` to be explicit instead of silently defaulting to
     MuJoCo's values, and dict values for these fields must cover every
     matched geom (add a catch-all ``".*"`` entry).
   - ``CommandTerm._update_command`` now takes an ``env_ids`` argument:
     ``None`` on the regular per-step update and the reset environment ids
     when called from ``reset()``. Custom command terms must add the
     parameter (construction raises a ``TypeError`` with migration
     instructions otherwise) and scope any per-step state advance, such as
     a motion frame index, to ``env_ids``.
   - ``ViewerConfig`` is now keyword-only; positional construction no
     longer works.

.. admonition:: Highlights
   :class: note

   - Upgraded to MuJoCo and MuJoCo Warp 3.11.
   - Upgraded ``rsl-rl-lib`` to 5.4.2.

Added
^^^^^

- Added ``GeomCfg``, exposed as the ``geoms`` field on ``EntityCfg``, a spec
  editor that matches geoms by name and patches their attributes. Supports
  ``group`` (so a geom can collide without being drawn) and all collision
  attributes; unset attributes are left untouched. Contribution by
  @bd-pmorais.
- Added ``diffuse``, ``specular``, ``ambient``, ``active``, and
  ``attenuation`` fields to ``LightCfg`` for configuring light color and
  falloff. Contribution by @bd-pmorais.
- Added ``random``, ``file``, ``cubefiles``, ``gridsize``, ``gridlayout``,
  ``nchannel``, ``hflip``, and ``vflip`` fields to ``TextureCfg``, so textures
  can be loaded from image files instead of only built-in patterns.
  ``width`` and ``height`` are now optional, since file-based textures take
  their size from the image. Contribution by @bd-pmorais.
- Added light domain randomization functions: ``dr.light_diffuse``,
  ``dr.light_specular``, ``dr.light_ambient``, ``dr.light_attenuation``,
  ``dr.light_cutoff``, and ``dr.light_exponent``. Contribution by @bd-pmorais.
- Added ``reduce="sum"`` to ``MetricsTermCfg`` for reporting the accumulated
  episode total (e.g. episodic reward, total distance traveled) instead of a
  per-step average. Contribution by @bd-mlutter
- Added ``ViewerConfig.geom_group`` and ``ViewerConfig.site_group`` to
  control which geom and site visualization groups the offscreen renderer
  draws. Defaults match MuJoCo's (groups 0 through 2), so rendering is
  unchanged unless configured. Contribution by @bd-mlutter.
- Added ``dr.mat_texid`` to randomize which texture fills a given
  ``mjtTextureRole`` slot (RGB by default) of each selected material,
  sampling uniformly from ``asset_cfg.texture_names``. Contribution by
  @bd-pmorais.

.. figure:: _static/changelog/mat_texid_dr.gif
   :width: 30%

Changed
^^^^^^^

- Bumped ``mujoco`` and ``mujoco-warp`` from 3.10 to 3.11, and regenerated the
  bundled MuJoCo type stubs.
- Bumped ``rsl-rl-lib`` from 5.4.0 to 5.4.2.
- ``CollisionCfg`` and ``GeomCfg`` now share one write path, and mjlab warns
  when a ``GeomCfg`` collision patch is overwritten by a ``CollisionCfg``.
- Changed the default MuJoCo Warp render background to solid black
  (``0, 0, 0, 1``), matching MuJoCo's native renderer. Contribution by
  @bd-pmorais.
- The offscreen renderer now works on a copy of the ``MjModel``, so its
  render-only tweaks (extent, shadows, reflections, offscreen size) no
  longer leak into the shared model. Contribution by @bd-mlutter.
- ``ViewerConfig`` is now keyword-only, with fields grouped and documented.
  Contribution by @bd-mlutter.
- ``ViewerConfig.fovy`` now also applies to the ``ASSET_ROOT`` and
  ``ASSET_BODY`` tracking cameras instead of being silently ignored; leave
  it at ``None`` (the default) to keep the model value. Contribution by
  @bd-mlutter.
- ``auto_reset`` and an explicit ``reset()`` now leave identical command and
  event timer state (:issue:`1133`).

Fixed
^^^^^

- The Viser motion scrubber's Start Here button no longer computes relative
  body poses from stale pre-scrub kinematics, which could spuriously
  terminate the episode on the next step.
- Mid-episode lifting command resamples now refresh kinematics and the
  multi-cube reward cache, so observations and rewards no longer see
  pre-teleport object positions for one step after each resample.
- ``UniformVelocityCommand``'s ``init_velocity_prob`` path no longer writes
  the previous episode's terminal pose back into the sim on reset. It read
  derived kinematics before ``forward()`` ran and rewrote the root pose; it
  now reads only qpos for the orientation and writes only the root velocity.
- ``init_velocity_prob`` now applies on episode reset only. A mid-episode
  timer resample used to also teleport the root velocity, which ran after
  ``step()``'s forward and left velocity observations stale for one step.
- ``Entity.set_joint_position_target`` and its velocity/effort/tendon/site
  siblings now select the outer product when both ``env_ids`` and the element
  ids are tensors, instead of pairing them elementwise.
- ``MotionCommand`` now refreshes kinematics after a timer-expiry resample
  (finite ``resampling_time_range``), matching its wraparound path.
- ``CircularBuffer`` lag retrieval now clamps to the oldest retained frame;
  a lag beyond the buffer length used to wrap around to a newer frame.
- Camera sensor caches are now invalidated after ``sense()``, so a
  pre-sense read with ``clone_data=True`` can no longer pin the previous
  step's frame into the observations (mirrors the raycast fix for
  :issue:`998`).
- ``reset(env_ids=...)`` no longer appends a frame to every env's observation
  history and delay buffers; only the reset envs receive their post-reset
  frame. Previously, each manual partial reset gave the other envs a duplicate
  frame, shortening their effective history and drifting their delay
  schedules.
- ``reset(env_ids=...)`` no longer advances stateful commands in
  environments that were not reset. Previously a partial reset gave every
  environment an extra command update, so with ``auto_reset=False`` a
  ``MotionCommand`` reference motion played at twice the normal speed and
  could teleport non-reset robots via the wraparound resample. The adaptive
  sampling EMA also no longer folds on resets, matching auto-reset
  training dynamics. :issue:`1138`
- Interval event timers are now resampled on episode reset for function-based
  terms, as documented. Previously the countdown carried across episodes, so a
  new episode's first ``push_robot`` in the velocity and tracking tasks could
  fire arbitrarily soon after spawn; with mixed function and class interval
  terms, reset also wrote into the wrong timer slots. Note this changes push
  timing relative to earlier training runs, and an interval term whose range
  exceeds the episode length is now re-armed on every reset and will never
  fire.
- ``RayCastSensorCfg.include_geom_groups`` now raises on values outside
  ``[0, mjNGROUP)`` instead of silently excluding every geom.
- Geoms with a negative group no longer pick up group 5's visibility toggle in
  the Viser viewer.

Version 1.5.3 (July 22, 2026)
-----------------------------

Changed
^^^^^^^

- The Viser reward bar panel's term cap is now configurable via
  ``ViewerConfig.reward_bar_max_terms``, so environments with more than 20
  reward terms can show them all. Defaults to 20, preserving previous behavior.
  :issue:`1079`

Fixed
^^^^^

- Bumped ``pillow`` (12.3.0), ``onnx`` (1.22.0), and ``soupsieve`` (2.9.1) in the
  lockfile to pick up security fixes.
- Fixed raycast sensor debug visualization and observations lagging one step
  behind the sensed hits. ``sense()`` rebinds the hit tensors after the cache had
  already been repopulated by a pre-sense reward read, so ``.data`` returned the
  previous step's hits; the cache is now invalidated after ``postprocess_rays``.
  With ``ray_alignment="yaw"`` this made debug rays appear tilted by the foot's
  per-step motion instead of vertical. :issue:`998`
- Restored ONNX uploads and W&B run metadata for velocity and manipulation
  training when using RSL-RL's current ``WandbLogWriter`` logger name.
- The Viser reward bar panel no longer *silently* drops reward terms beyond
  ``max_terms``; it now emits a warning listing the hidden terms. Previously
  environments with more than 20 reward terms had the overflow disappear from
  the bar panel with no indication. :issue:`1079`
- Fixed the ``terrain_levels_vel`` curriculum promoting every env from level 0
  to level 1 on the initial reset, ignoring ``max_init_terrain_level=0``. Before
  the first step the robot sits at its spawn pose rather than a walked-to
  position, so the distance check was spurious; terrain levels are now frozen on
  that first reset. :issue:`1094`
- Fixed the velocity task's actor ``joint_pos`` observation not being biased by
  the ``encoder_bias`` domain randomization, so the encoder bias only affected
  actions and never the observed joint positions. The actor now observes biased
  joint positions while the critic keeps the true (unbiased) values as
  privileged information, matching the tracking task.
  See `discussion #1065 <https://github.com/mujocolab/mjlab/discussions/1065>`_.
- Hardened ``fit_terrain_normal`` against non-finite raycast hits. A single env
  with a diverged state produced a NaN/Inf covariance that made
  ``torch.linalg.eigh`` raise and abort the whole batch; such rows now fall back
  to the up vector. This stops the hard crash so a diverged env can be reset
  normally; it does not by itself make a diverged env's downstream reward finite.
  :issue:`912`
- Enabled ``obs_normalization`` on the Go1 velocity actor and critic to match
  the other velocity tasks. Without it, extreme-but-finite observations on rough
  terrain drove value/policy divergence that eventually surfaced as a
  ``normal expects all elements of std >= 0.0`` crash. Note that Go1 velocity
  checkpoints trained before this change carry no normalizer buffers and will no
  longer load; retrain from scratch. :issue:`870` :issue:`1044` :issue:`1053`
- Fixed ``ContactSensor`` air-time tracking accumulating float32 sim-clock
  differences, whose quantization error grows with the clock magnitude and made
  ``compute_first_contact`` / ``compute_first_air`` miss touchdowns on long runs.
  The exact float64 substep ``dt`` is now accumulated instead. :issue:`1101`
- Bumped ``mujoco-warp`` to 3.10.0.3, fixing a CUDA 700 illegal memory access in
  ``smooth.crb`` triggered by startup mass domain randomization (via
  ``set_const``) once ``num_envs >= 128`` on consumer Ada GPUs. :issue:`1108`

Version 1.5.2 (July 17, 2026)
-----------------------------

Fixed
^^^^^

- Fixed CUDA illegal memory accesses when domain randomization triggers
  ``set_const`` with multiple environments. ``actuator_acc0`` is now expanded
  per environment before MuJoCo Warp recomputes it.
- Fixed ``MaterialCfg.reflectance`` being ignored when building the MuJoCo
  spec. Contribution by @bd-pmorais.

Version 1.5.1 (July 15, 2026)
-----------------------------

Added
^^^^^

- Added ``MeshCfg``, a spec editor that matches mesh assets by name and edits
  their asset-level attributes. The first attribute is ``maxhullvert``, which
  caps the collision convex hull's vertex count to lower narrowphase cost.
- Added ``SimulationCfg.broadphase`` and ``SimulationCfg.broadphase_filter``
  to configure MuJoCo Warp's broadphase collision algorithm and
  bounding-volume filters.

Changed
^^^^^^^

- Enabled skybox rendering for camera sensors. Contribution by @bd-pmorais.
- Bumped the minimum ``mujoco-warp`` to 3.10.0.2, which fixes ``qfrc_constraint``
  being populated incorrectly across vectorized environments (:issue:`1086`).
  Earlier 3.10.0.x releases are no longer supported.
- Command delay on fusable actuators (ideal PD, DC motor) now applies one shared
  lag per environment across all fused actuators sharing a delay config, matching
  the built-in actuator path, rather than an independent lag per actuator group
  (:issue:`1035`).

Fixed
^^^^^

- Fixed ``TerrainGenerator`` overwriting custom geom names set by sub-terrain
  functions with the default ``terrain_{i}`` name. Only unnamed geoms are now
  auto-named.
- Fixed ``TorchArray`` not expanding world-shared model fields to ``nworld``
  with mujoco_warp 3.10.0.2, which allocates them as real size-1 arrays
  instead of stride-0 broadcast views. Multi-env indexing of fields like
  ``soft_joint_pos_limits`` raised ``IndexError`` during resets (:issue:`1093`).
- Fixed ``mdp.bad_orientation`` returning NaN when float32 rounding in
  ``quat_apply_inverse`` pushed the projected-gravity z-component slightly
  outside ``[-1, 1]``, making ``torch.acos`` return NaN and silently
  suppressing the termination for flipped robots. The argument is now clamped
  to ``[-1, 1]``.
- Fixed a crash when using command delay on ideal PD (or other custom)
  actuators whenever ``num_envs`` differed from the number of delayed targets,
  and fused ideal PD and DC motor actuators sharing a transmission and delay
  config into a single gather, delay, control-law evaluation, and control
  write, removing per-group host overhead (:issue:`1035`).

Version 1.5.0 (June 28, 2026)
-----------------------------

Added
^^^^^

- Added ``reduce="max"`` to ``MetricsTermCfg`` for reporting episode-peak values
  (e.g. peak power, peak contact force) without needing stateful wrapper classes.
- Added ``BuiltinDcMotorActuator``, a native MuJoCo ``<dcmotor>`` wrapper.
  Supports voltage / position / velocity input modes with back-EMF,
  configurable motor constants, and optional integral, slew, inductance,
  thermal, LuGre, and cogging extensions.
- Added ``scale_with_difficulty`` to ``HfRandomUniformTerrainCfg``. When
  enabled, the noise amplitude scales with difficulty (flat at 0, full
  ``noise_range`` at 1) so the terrain progresses in a curriculum. Defaults to
  ``False``, preserving the previous difficulty-independent behavior.
- Added material domain randomization functions for MuJoCo Warp RGB rendering:
  ``dr.mat_emission``, ``dr.mat_specular``, ``dr.mat_shininess``, and
  ``dr.mat_texrepeat``.

Changed
^^^^^^^

- Bumped ``rsl-rl-lib`` from 5.2.0 to 5.4.0.
- Bumped ``mujoco`` and ``mujoco-warp`` to 3.10, both pinned from PyPI. The
  ``py.mujoco.org`` nightly index and the ``mujoco-warp`` git pin are dropped, so
  resolution no longer breaks when nightly wheels are garbage-collected.

  .. warning::

     ``SimulationCfg.ls_parallel`` is deprecated and now ignored, since parallel
     linesearch was removed upstream in MuJoCo Warp. Setting it emits a
     ``DeprecationWarning``; remove it from any ``SimulationCfg`` you construct.
- Curriculum-mode terrain difficulty is now deterministic across rows
  and reaches the configured ``difficulty_range`` endpoints
  (:issue:`1027`).
- Heightfield terrains now color by absolute height with a diverging palette
  (cool below the ground plane, green at ground level, warm above) on a fixed
  scale, replacing the per-patch normalization. Color is now consistent across
  terrains, and low-amplitude terrain such as ``random_rough`` reads as gently
  tinted ground instead of high-contrast noise.
- ``BoxNestedRingsTerrainCfg`` now builds uniform-height concentric ridges
  whose separating gaps widen with difficulty, replacing the random per-ring
  heights. Rings are colored by height (like the other terrains) and the outer
  border matches the ring height.
- Terrain generation no longer prints timing information to stdout.

Fixed
^^^^^

- Fixed domain randomization events that target different ``axes`` of the same
  model field (e.g. two ``dr.geom_size`` events scaling axis 0 and axis 1
  separately) silently clobbering each other. Each event now writes back only
  the axes it targeted, so per-axis events compose (:issue:`1042`).
- Regenerated the bundled MuJoCo type stubs, which had drifted from the
  installed mujoco version. CI now regenerates them and fails if they are
  stale, so they stay in sync going forward. Run ``make stubs`` to update them
  (:issue:`1048`).
- Fixed ``select_gpus`` crashing when ``CUDA_VISIBLE_DEVICES`` contains MIG
  UUIDs instead of numeric indices.
- Fixed pyramid-stairs terrains (``BoxPyramidStairsTerrainCfg``,
  ``BoxInvertedPyramidStairsTerrainCfg``, and ``BoxOpenStairsTerrainCfg``)
  leaving an empty, geometry-free border at difficulty 0, where the step
  height collapses to zero. The flat border frame is now always generated as
  solid geometry flush with the ground (:issue:`1033`).
- Fixed ``HfPerlinNoiseTerrainCfg`` failing to compile at difficulty 0, where
  the target height collapses to zero and MuJoCo rejects the non-positive
  heightfield size.
- Fixed ``BoxRandomGridTerrainCfg`` producing NaN colors (and failing to build)
  at difficulty 0, where the grid height is zero and the color normalization
  divided by zero.
- Fixed the center platform z-fighting with surrounding geometry in
  ``BoxRandomGridTerrainCfg`` (grid cells were left underneath the platform) and
  ``BoxRandomSpreadTerrainCfg`` (the platform duplicated the floor surface).
- Fixed ``BoxNarrowBeamsTerrainCfg`` square platform corners protruding between
  the beams at high difficulty; the platform now shrinks to stay within the
  beams' angular coverage.
- Fixed ``BoxSteppingStonesTerrainCfg`` reconfiguring abruptly at a difficulty
  threshold, where the stone grid re-tiled as its spacing crossed an integer
  boundary, and leaving an oversized gap around the center platform. The grid is
  now difficulty-independent and the platform snaps to it as a clean island.
- Fixed ``train --video``, ``play``, and ``demo`` crashing with ``OpenGL
  platform library not loaded`` on headless Linux hosts that don't pre-set
  ``MUJOCO_GL``. The default is now applied in ``mjlab/__init__.py`` (Linux
  only) so it takes effect before mujoco's GL backend selection runs.
- Fixed motion tracking re-anchoring to a stale robot pose after a mid-episode
  motion resample. ``MotionCommand._update_command`` now calls ``sim.forward()``
  after resampling so relative body poses read the post-teleport state
  (:issue:`1068`).

Version 1.4.0 (May 26, 2026)
----------------------------

Added
^^^^^

- Added ``BuiltinPdActuator``, the implicit-integration version of
  ``IdealPdActuator``. Same interface (position + velocity targets,
  kp/kd gains), but expresses the PD as native MuJoCo ``<position>``
  and ``<velocity>`` elements so the ``implicit`` / ``implicitfast``
  integrators include the kp/kd derivatives in their velocity update.
  The actuator stays stable at gain/timestep combinations where
  explicit Python PD would diverge, which matters when you want to
  run a real motor's stiff on-board PD gains in sim. ``effort_limit``
  is enforced as a sum-clamp on the two PD terms via
  ``jnt_actfrcrange`` (or ``tendon_actfrcrange``). Supported by
  ``dr.pd_gains`` and ``dr.effort_limits``.
- Added ``mdp.projected_gravity_from_sensor``, an observation that derives
  projected gravity from a ``framezaxis`` up-vector sensor (negated) rather
  than from the root body orientation. Unlike ``mdp.projected_gravity``, it
  reflects the sensor's site frame, so it can observe IMU mounting domain
  randomization (e.g. via ``dr.site_quat``). Go1 and G1 ship an
  ``imu_upvector`` sensor for this.
- Added ``DebugVisualizer.add_box`` for drawing an axis-oriented box
  primitive, mirroring ``add_ellipsoid``. Supported by both the native
  and Viser viewers. ``size`` is the box half-extents (:issue:`992`).
- Added ``--log-root`` CLI option to ``train``, ``play``, and ``evaluate``
  scripts for choosing where training logs are stored. Defaults to
  ``logs/rsl_rl`` (unchanged behavior). Useful for directing outputs to a
  scratch disk or shared mount.
- ``RewardManager``, ``TerminationManager``, and ``MetricsManager`` now
  validate that every term function returns a tensor of shape
  ``(num_envs,)`` when evaluated, raising a clear ``ValueError``
  naming the offending term instead of silently broadcasting or crashing
  with an opaque error later during training.
- Added ``ContactSensor.primary_names`` property to expose the resolved
  primary names in the order they appear along the per-contact axis of the
  output tensors. This makes it possible to map a contact-data column back
  to the primary it belongs to (:issue:`914`).
- Added per-world mesh variant support via ``VariantEntityCfg``. Each
  world in a batched simulation can now use a different mesh asset for
  the same logical entity (e.g. world 0 holds a cube, world 1 a
  sphere). Variants are passed as a ``dict[str, Callable]`` of named
  spec callables; the optional ``assignment`` field controls how worlds
  map to variants and accepts ``None`` (uniform), a ``dict[str, float]``
  of per-variant weights, or a custom ``Callable[[int], Sequence[int]]``.
  Mesh-derived constants (collision bounds, body inertials, subtree
  mass, inverse weights) are compiled per-variant and stored as
  per-world arrays in the Warp model, so domain randomization, the
  native viewer, the offscreen renderer, and the Viser viewer all pick
  up the variant assignment automatically. Variants must share the
  same kinematic structure (same bodies, joints, joint types); only
  mesh geoms may differ. Assignment is fixed at simulation init. See
  :ref:`heterogeneous_worlds` for usage. With help from @XiangruiJiang.
- Per-world mesh variants now support per-variant materials and textures.
  Each variant can reference its own named material, which is automatically
  prefixed and scattered via ``geom_matid`` alongside the existing
  ``geom_dataid`` table. Variants without a material get ``matid = -1``.
  Contribution by @omarrayyann.
- Added ``dr.geom_matid`` to randomize which baked material each geom uses
  per environment, sampling uniformly from ``asset_cfg.material_names``.
  Contribution by @bd-pmorais.

Changed
^^^^^^^

- ``Entity`` now raises a clear error at construction when its spec contains
  more than one freejoint. An entity models a single system rooted at one
  body, so it has at most one freejoint; a second one was previously accepted
  silently and only surfaced later as a cryptic shape mismatch when writing
  root state. Model each detached floating body as its own entry in
  ``SceneCfg.entities`` instead.
- Changed ``compute_root_relative_mpkpe`` to re-anchor the reference to the
  robot's root each step, removing yaw drift as well as translation so it
  measures intrinsic body pose error.
- Changed ``compute_joint_velocity_error`` from an L2 norm to a per-joint
  RMS, so it no longer scales with the number of joints.
- Bumped ``mujoco`` to 3.8 and ``mujoco-warp`` to 3.8.0. The ``multiccd``
  enable flag was removed in mujoco 3.8 (it became default-on), so configs
  that listed ``"multiccd"`` in ``MujocoCfg.enableflags`` need to drop it.
- Camera segmentation now matches ``mujoco_warp``'s typed segmentation
  output. ``CameraSensorData.segmentation`` stores ``(object_id,
  object_type)`` pairs in shape ``[B, H, W, 2]`` instead of the previous
  legacy geom-id-only layout. Contribution by @tkelestemur.
- Sped up ``RayCaster`` post-processing by removing boolean-mask indexing
  operations and replacing them with ``masked_fill_`` plus a clamped-distance
  formulation of ``hit_pos_w`` that places misses at the world origin. This
  removes all CUDA syncs from the ray post-process, letting the CPU thread
  proceed while GPU-based sensing runs. Contribution by @bd-pdomanico.
- Bumped ``rsl-rl-lib`` from 5.0.1 to 5.2.0. This brings ``torch.compile`` support for
  PPO and Distillation, and optional std clamping and constant std in
  ``GaussianDistribution``. No code changes required on the mjlab side.
- ``TerrainEntityCfg`` debug visualization sites (environment origins,
  terrain origins, flat patches) are now off by default. Set
  ``debug_vis=True`` to re-enable them. The sites inflated ``nsite`` and
  caused a measurable slowdown in the per-step ``site_local_to_global``
  kernel (:issue:`942`).
- Task package load failures during ``mjlab`` import now print the full
  traceback (and the entry point's module path) to ``stderr`` instead of
  just the exception message, making it easier to pinpoint the source of
  import errors when running commands like ``list-envs`` (:issue:`910`).
  Contribution by @saikishor.
- Clarified ``ContactSensor`` shape conventions: per-contact fields
  (``found``, ``force``, ``torque``, ``dist``, ``pos``, ``normal``,
  ``tangent``) have shape ``[B, P * num_slots, ...]`` while per-primary
  air-time fields (``current_air_time``, ``last_air_time``,
  ``current_contact_time``, ``last_contact_time``) have shape ``[B, P]``,
  where ``P`` is the number of resolved primaries (:issue:`914`).
- Event functions now share a single ``resolve_env_ids`` helper to expand
  ``env_ids=None`` to all environments, replacing five copies of the same
  guard. ``push_by_setting_velocity`` and ``apply_external_force_torque``
  accept ``env_ids=None`` too, so they work as global-time interval terms.
  Documented when to use ``apply_external_force_torque`` (a constant,
  self-managed wrench) versus ``apply_body_impulse`` (transient, automatic
  impulses) versus ``push_by_setting_velocity`` (an instantaneous velocity
  kick).

Fixed
^^^^^

- Removed use of deprecated ``warp-lang`` symbols (``wp.context.runtime``
  and ``wp.context.Device``) that were dropped in newer ``warp-lang``
  releases, causing ``AttributeError: module 'warp' has no attribute
  'context'`` at import/runtime. mjlab now uses
  ``wp.get_cuda_driver_version()`` and ``wp.Device`` instead
  (:issue:`967`). Contribution by @rdeits.
- Fixed the tracking ``evaluate`` script scoring each metric against the
  next motion frame; the reference is now snapshotted before each step to
  match the reward.
- Fixed the tracking end-effector metrics silently scoring zero for an
  unknown body name; they now raise ``ValueError``.
- Fixed ``compute_mpkpe`` measuring root-relative instead of global error;
  it now uses the global reference ``body_pos_w`` (:issue:`1006`).
- Fixed heavy flicker in offscreen training videos on rough-terrain tasks.
  The renderer recomputed its context "neighbor" robots every frame from
  ``env_origins``, which the terrain curriculum mutates on reset, so the
  neighbor set kept changing and robots popped in and out. The neighbor
  set is now computed once and cached (:issue:`979`).
- Fixed command delay only applying to an actuator's position target.
  ``IdealPdActuator`` and ``DcMotorActuator`` also use velocity and effort, which
  arrived undelayed and out of sync; all command targets now share one delay.
  Zero-reference setups are unaffected.
- Fixed duplicate random seeds across nodes in multi-node training. The
  per-process seed offset in ``scripts/train.py`` now uses the global
  ``RANK`` instead of ``LOCAL_RANK``. Contribution by @bd-pdomanico.
- Fixed ``apply_body_impulse`` firing an impulse on the very first step (and
  the first step after every reset) instead of starting with a cooldown as
  documented. The cooldown is now sampled lazily on the first call so impulse
  timing is decorrelated from episode resets (:issue:`973`).
- Fixed ``dr.pd_gains`` and ``dr.effort_limits`` silently no-oping when
  passed an ``Operation`` object (e.g. ``dr.scale``) instead of a string.
  Both functions now accept ``Operation | str`` like every other DR event
  and raise ``ValueError`` for unsupported operations (:issue:`971`).
- Fixed ``ContactSensor`` with ``global_frame=True`` and
  ``reduce`` ∈ {``"none"``, ``"mindist"``, ``"maxforce"``} producing forces
  rotated onto the wrong axis. The contact-frame→world rotation matrix had
  its columns ordered ``[tangent, tangent2, normal]`` instead of
  ``[normal, tangent, tangent2]``, projecting the normal-force component
  onto a tangent direction. Contribution by @bd-pdomanico.
- Fixed ``extras["log"]`` entries written by reward terms (e.g. ``Metrics/*``
  values in velocity tasks) being silently discarded on any step where at
  least one environment resets. ``_reset_idx`` was clearing the dict after
  ``reward_manager.compute()`` had already populated it. The clear now
  happens at the top of ``step()`` and ``reset()`` so that all entries
  survive (:issue:`957`).
- Fixed ``ContactSensor.compute_first_contact`` and ``compute_first_air``
  occasionally missing events when a contact began or ended right at the
  last physics substep of a control step. ``current_contact_time`` /
  ``current_air_time`` accumulate in float32 and can drift a few ULPs past
  ``dt``, but the default ``abs_tol`` of ``1e-8`` sat at the noise floor
  and rejected the comparison. Raised the default to ``1e-6``, which stays
  well below typical control ``dt`` while comfortably covering float32
  accumulation noise (:issue:`933`). Contribution by @paLeziart.
- Fixed ``out_of_terrain_bounds`` using stale terrain dimensions. It read
  ``TerrainGeneratorCfg.num_cols`` directly, which is ignored in curriculum
  mode (the generator uses ``len(sub_terrains)`` columns instead), and it
  did not account for ``border_width``. The termination now reads the
  effective grid shape from ``terrain.terrain_origins`` and includes the
  border in the footprint, so robots no longer reset while still on valid
  terrain (or fail to reset after running off it) (:issue:`923`).
- ``ObservationManager`` now skips observation groups that end up with
  zero active terms (e.g. all terms set to ``None``) with a log message,
  instead of crashing later in ``torch.stack``/``torch.cat``. This lets
  a shared runner config define groups that become empty under certain
  runtime flags (e.g. model-specific terms all disabled for one variant).
  The whole group can still be set to ``None`` to disable it explicitly.
- Fixed a runtime broadcast error in ``ContactSensor`` when combining
  ``num_slots > 1`` with ``track_air_time=True`` and more than one primary.
  Air-time tracking now reduces ``found`` across slots so that a primary is
  considered in contact when any of its slots reports a match (:issue:`914`).
- Updated the ``create_new_task.ipynb`` Colab tutorial to import
  ``XmlActuatorCfg`` instead of the removed ``XmlVelocityActuatorCfg``.
  Added a regression test (``tests/test_notebooks.py``) that parses each
  notebook cell and verifies that every ``from mjlab... import X``
  reference resolves, so future renames in the mjlab public API can't
  silently rot the tutorials (:issue:`913`).
- Fixed ``ObservationManager`` silently sharing a single ``NoiseModelCfg``
  instance across observation groups that declared terms with the same
  name. ``_group_obs_class_instances`` was keyed by term name alone, so
  the last group processed in ``_prepare_terms`` overwrote earlier
  groups' instances. Symptoms included the wrong noise config being
  applied, shared per-episode state for ``NoiseModelWithAdditiveBias``
  (e.g. bias drawn from the wrong ``bias_noise_cfg``), and missed
  ``reset()`` calls for overwritten instances. Instances are now keyed
  by ``(group_name, term_name)`` so each group owns its own noise model.
- Fixed ``CurriculumManager.get_active_iterable_terms`` raising
  ``TypeError`` when a term's state was a dict. The dict branch indexed
  the output list by term name instead of appending to the local ``data``
  list. No in-tree caller currently invokes this method, so the bug was
  latent.

Version 1.3.0 (April 14, 2026)
------------------------------

Added
^^^^^

- Added ``ManagerBasedRlEnvCfg.auto_reset`` flag. When ``True`` (default),
  ``step()`` continues to reset done environments in place and returns the
  post-reset observation. When ``False``, ``step()`` skips the reset block
  and returns the terminal observation directly; the caller must call
  ``reset(env_ids=...)`` for done environments before the next ``step()``
  or a ``RuntimeError`` is raised. Enables access to the true terminal
  state for algorithms that need it. Note that mjlab's bundled ``train.py``
  uses rsl_rl's ``OnPolicyRunner``, which does not drive manual resets, so
  ``auto_reset=False`` is intended for custom training loops (:issue:`900`).
- Added ``ActuatorCfg.viscous_damping`` for passive velocity proportional
  damping (``f = -b·v``), distinct from the PD derivative gain ``damping``
  used by position and velocity actuators. Maps to ``<joint damping>`` for
  JOINT transmission and ``<tendon damping>`` for TENDON transmission.
  Defaults to ``None`` (preserves the XML value).
- Added :class:`~mjlab.managers.RecorderManager` for logging observations,
  actions, or arbitrary environment data during rollouts. Implement a
  :class:`~mjlab.managers.RecorderTerm` subclass and register it in the
  ``recorders`` dict on ``ManagerBasedRlEnvCfg``. The manager provides
  ``record_pre_reset``, ``record_post_reset``, and ``record_post_step``
  lifecycle hooks with no opinion on how data is stored.
- Added :func:`~mjlab.envs.mdp.curriculums.termination_curriculum` for
  scheduling changes to termination term parameters during training,
  matching the existing ``reward_curriculum`` pattern. Both now share a
  single internal engine with init-time validation of stage ordering,
  field existence, and param keys.
- Added ``reduce`` field to ``MetricsTermCfg``. Setting ``reduce="last"``
  reports the value from the final step of the episode rather than the
  episode mean, which is useful for binary success metrics.
- Added :class:`~mjlab.envs.mdp.actions.RelativeJointPositionAction` for
  joint position control relative to the current configuration. The target is
  ``current_pos + action * scale``, so a zero action holds the current
  configuration rather than commanding the default pose.
- Added :func:`~mjlab.envs.mdp.dr.pair_friction` for randomizing geom-pair
  friction overrides (``pair_friction`` in ``mjModel``), with an
  ``isotropic=True`` option that mirrors the symmetric tangent and roll
  axes so single-axis randomization does not leave the paired axis stale.
- Added ``STAIRS_TERRAINS_CFG`` terrain preset for progressive stair
  curriculum training and ``@terrain_preset`` decorator for composing
  terrain configurations from reusable presets.
- Added cartpole balance and swingup tasks (``Mjlab-Cartpole-Balance`` and
  ``Mjlab-Cartpole-Swingup``) with a :ref:`tutorial <tutorial-cartpole>`
  that walks through building an environment from scratch.
- Added :ref:`motion imitation <motion-imitation>` documentation with
  preprocessing instructions. The README now links here instead of the
  BeyondMimic repository, which produced incompatible NPZ files when used
  with mjlab (:issue:`777`).
- Added ``margin``, ``gap``, and ``solmix`` fields to ``CollisionCfg``
  for per geom contact parameter configuration (:issue:`766`).
- NaN guard now captures mocap body poses (``mocap_pos``, ``mocap_quat``)
  when the model has mocap bodies, enabling full state reconstruction in
  the dump viewer for fixed-base entities.
- Implemented ``ActionTermCfg.clip`` for clamping processed actions after
  scale and offset (:issue:`771`).
- Added ``qfrc_actuator`` and ``qfrc_external`` generalized force accessors
  to ``EntityData``. ``qfrc_actuator`` gives actuator forces in joint space
  (projected through the transmission). ``qfrc_external`` recovers the
  generalized force from body external wrenches (``xfrc_applied``)
  (:issue:`776`).
- Added ``RewardBarPanel`` to the Viser viewer, showing horizontal bars for
  each reward term with a running mean over ~1 second (:issue:`800`).
- Added ``per_substep`` flag to ``MetricsTermCfg`` for evaluating metrics
  once per physics substep inside the decimation loop. The per substep
  values are averaged within each environment step, so episode averages
  remain comparable to regular per step metrics.
- Added ``project-instinct/InstinctMJ`` to the research page's list of
  projects built on mjlab.
- Added a Checkpoints tab to the Viser play viewer for hot-swapping
  checkpoints without restarting. Works with local directories and W&B
  runs (:issue:`751`). Contribution by @omarrayyann.
- Added ``"segmentation"`` camera data type for per-pixel geom ID output
  alongside RGB and depth, and a multi-cube goal-conditioned lifting task
  (``Mjlab-Multi-Cube-Seg-Yam``) that uses it (:issue:`862`).
  Contribution by @pthangeda.

Changed
^^^^^^^

- Renamed the ``list_envs`` console script to ``list-envs`` for consistency
  with the other hyphenated entry points (``viz-nan``, ``export-scene``).
  Invoke via ``uv run list-envs``.
- ``ActuatorCfg.armature`` and ``ActuatorCfg.frictionloss`` now default to
  ``None`` instead of ``0.0``. ``None`` preserves the value defined in the
  XML. Previously, builtin actuators would silently overwrite XML joint and
  tendon properties with zero when these fields were not explicitly set.
  To restore the old behavior, pass ``armature=0.0`` or ``frictionloss=0.0``
  explicitly.
- Actuator delay is now configured inline on any ``ActuatorCfg`` subclass
  (e.g. ``BuiltinPositionActuatorCfg(..., delay_min_lag=2, delay_max_lag=5)``)
  instead of wrapping with ``DelayedActuatorCfg``. ``DelayedActuator``,
  ``DelayedActuatorCfg``, and ``DelayedBuiltinActuatorGroup`` are removed.
- Removed ``delay_target`` from ``ActuatorCfg``. Delay now always applies to
  the actuator's ``command_field`` automatically. Multi-target delay
  (``delay_target=("position", "velocity")``) is no longer supported.
- ``XmlPositionActuatorCfg``, ``XmlVelocityActuatorCfg``, ``XmlMotorActuatorCfg``,
  and ``XmlMuscleActuatorCfg`` are replaced by a single ``XmlActuatorCfg`` that auto
  detects the actuator type from XML. Pass ``command_field=...`` to override detection.
- Replaced the viser viewer internals with the ``mjviser`` package. Scene
  creation, mesh conversion, and overlay rendering (contacts, forces,
  inertia, tendons, joints, frames) are now provided by mjviser. The viewer
  exposes a new Visualization tab for overlay controls and a Groups tab for
  geom/site visibility. Debug visualization and warp tensor conversion remain
  in mjlab's ``MjlabViserScene`` subclass (:issue:`839`).
- In curriculum terrain mode, each terrain type now gets exactly one column
  (``num_cols`` is set to ``len(sub_terrains)``). The ``proportion`` field
  now controls robot spawning distribution across columns rather than column
  count. Random mode is unchanged (:issue:`811`).
- ``BoxSteppingStonesTerrainCfg`` stone size now decreases with difficulty,
  interpolating from the large end of ``stone_size_range`` at difficulty 0
  to the small end at difficulty 1 (:issue:`785`).
- Removed deprecated ``TerrainImporter`` and ``TerrainImporterCfg`` aliases.
  Use ``TerrainEntity`` and ``TerrainEntityCfg`` instead (:issue:`667`).
- ``Entity.clear_state()`` is deprecated. Use ``Entity.reset()`` instead.
  ``clear_state`` only zeroed actuator targets without resetting actuator
  internal state (e.g. delay buffers), which could cause stale commands
  after teleporting the robot to a new pose.
- Removed ``EntityData.generalized_force``. The property was bugged (indexed
  free joint DOFs instead of articulated DOFs) and the name was ambiguous.
  Use ``qfrc_actuator`` or ``qfrc_external`` instead (:issue:`776`).
- ``get_wandb_checkpoint_path`` now filters checkpoints server-side via the
  ``pattern`` parameter, avoiding unnecessary pagination and tolerance to
  corrupted metadata (:issue:`898`).

Fixed
^^^^^

- ``train`` and ``play`` now print a top-level usage message when invoked
  with ``-h`` / ``--help`` and no task argument, pointing users at
  ``list-envs`` and ``<TASK> --help`` (:issue:`905`).
- Fixed ghost geom filtering in the Viser viewer. Ghost geoms were selected
  by collision flags, so collision-disabled robot geoms appeared as ghosts.
  The viewer now uses visual alpha to determine which geoms to render.
- Scene now warns when an attached entity or terrain spec has non-default
  ``<option>`` fields (e.g. ``<flag contact="disable"/>``), which are
  silently dropped by ``MjSpec.attach()``. Use ``MujocoCfg`` to set
  simulation options instead (:issue:`885`).
- Fixed ``SceneEntityCfg`` names and IDs ordering mismatch when
  ``preserve_order=False`` (:issue:`876`). Contribution by @jsw7460.
- Fixed ONNX export path resolution in the velocity, manipulation, and
  tracking runners when a parent directory name contains the word
  ``"model"`` (:issue:`867`). Contribution by @gokulp01.
- ``export-scene`` now writes only referenced assets and places them
  correctly under the output directory. Previously, asset keys containing
  path traversal could write files outside the output directory, and all
  spec assets were included regardless of whether the scene XML referenced
  them (:issue:`858`).
- ``electrical_power_cost`` now uses ``qfrc_actuator`` (joint space) instead
  of ``actuator_force`` (actuation space) for mechanical power computation.
  Previously the reward was incorrect for actuators with gear ratios other
  than 1 (:issue:`776`).
- ``create_velocity_actuator`` no longer sets ``ctrllimited=True`` with
  ``inheritrange=1.0``. This caused a ``ValueError`` for continuous joints
  (e.g. wheels) that have no position range defined (:issue:`787`).
- ``write_root_com_velocity_to_sim`` no longer fails with tensor ``env_ids``
  on floating base entities (:issue:`793`).
- Joint limits for unlimited joints are now set to [-inf, inf] instead of
  [0, 0]. Previously the zero range caused incorrect clamping for entities
  with unlimited hinge or slide joints.
- Contact force visualization now copies ``ctrl`` into the CPU ``MjData``
  before calling ``mj_forward``. Actuators that compute torques in Python
  (``DcMotorActuator``, ``IdealPdActuator``) previously showed incorrect
  contact forces because the viewer ran with ``ctrl=0``
  (:issue:`786`).
- ``BoxSteppingStonesTerrainCfg`` no longer creates a large gap around the
  platform. Stones are now only skipped when their center falls inside the
  platform; edges that extend under the platform are allowed since the
  platform covers them (:issue:`785`).
- ``dr.pseudo_inertia`` no longer loads cuSOLVER, eliminating ~4 GB of
  persistent GPU memory overhead. Cholesky and eigendecomposition are now
  computed analytically for the small matrices involved (4x4 and 3x3)
  (:issue:`753`).
- Set terrain geom mass to zero so that the static terrain body does not
  inflate ``stat.meanmass``, which made force arrow visualization invisible
  on rough terrain (:issue:`734`, :issue:`537`).
- Native viewer now syncs ``qpos0`` when domain randomized, fixing incorrect
  body positions after ``dr.joint_default_pos`` randomization
  (:issue:`760`).
- ``command_manager.compute()`` is now called during ``reset()`` so that
  derived command state (e.g. relative body positions in tracking
  environments) is populated before the first observation is returned
  (:issue:`761`).
- ``RayCastSensor`` with ``ray_alignment="yaw"`` or ``"world"`` now correctly
  aligns the frame offset when attached to a site or geom with a local offset
  from its parent body. Previously only ray directions and pattern offsets were
  aligned, causing the frame position to swing with body pitch/roll
  (:issue:`775`).

Version 1.2.0 (March 6, 2026)
-----------------------------

.. admonition:: Breaking API changes
   :class: attention

   - ``randomize_field`` no longer exists. Replace calls with typed functions
     from the new ``dr`` module (e.g. ``dr.geom_friction``, ``dr.body_mass``).
   - ``EventTermCfg`` no longer accepts ``domain_randomization``. The
     ``@requires_model_fields`` decorator on each ``dr`` function takes care
     of field expansion automatically.
   - ``Scene.to_zip()`` is deprecated. Use ``Scene.write(path, zip=True)``.
   - ``RslRlModelCfg`` no longer accepts ``stochastic``, ``init_noise_std``,
     or ``noise_std_type``. Use ``distribution_cfg`` instead
     (e.g. ``{"class_name": "GaussianDistribution", "init_std": 1.0,
     "std_type": "scalar"}``). Existing checkpoints are automatically
     migrated on load.

Added
^^^^^

- Added ``"step"`` event mode that fires every environment step.
- Added ``apply_body_impulse`` event for applying transient external wrenches
  to bodies with configurable duration and optional application point offset.
- ONNX auto-export and metadata attachment for manipulation tasks (lift cube)
  on every checkpoint save, matching the velocity and tracking task behavior.
- Multi-frame ``RayCastSensor``: pass a tuple of ``ObjRef`` to ``frame`` for
  per-site raycasting with independent body exclusion. New properties:
  ``num_frames``, ``num_rays_per_frame``. New ``RayCastData`` fields:
  ``frame_pos_w`` and ``frame_quat_w``.
- ``RingPatternCfg`` ray pattern for concentric ring sampling around each
  frame.
- ``TerrainHeightSensor``, a ``RayCastSensor`` subclass that computes
  per-frame vertical clearance above terrain (``sensor.data.heights``).
  Velocity task configs now use it for ``feet_clearance``,
  ``feet_swing_height``, and ``foot_height``, replacing the previous
  world-Z proxy that was incorrect on rough terrain.
- Cloud training support via `SkyPilot <https://skypilot.readthedocs.io/>`_
  and Lambda Cloud, with documentation covering setup, monitoring, and
  cost management.
- W&B hyperparameter sweep scripts that distribute one agent per GPU
  across a multi-GPU instance.
- Contributing guide with documentation for shared Claude Code commands
  (``/update-mjwarp``, ``/commit-push-pr``).
- Added optional ``ViewerConfig.fovy`` and apply it in native viewer camera
  setup when provided.
- Native viewer now tracks the first non-fixed body by default (matching
  the Viser viewer behavior introduced in
  ``716aaaa58ad7bfaf34d2f771549d461204d1b4ba``).
- New ``dr`` module (``mjlab.envs.mdp.dr``) replacing ``randomize_field``
  with typed per-field domain randomization functions. Each function
  automatically recomputes derived fields via ``set_const``. Highlights:

  - Camera and light randomization: ``dr.cam_fovy``, ``dr.cam_pos``,
    ``dr.cam_quat``, ``dr.cam_intrinsic``, ``dr.light_pos``,
    ``dr.light_dir``. Camera and light names are now supported in
    ``SceneEntityCfg`` (``camera_names`` / ``light_names``).
  - ``dr.pseudo_inertia`` for physics-consistent randomization of
    ``body_mass``, ``body_ipos``, ``body_inertia``, and ``body_iquat``
    via the pseudo-inertia matrix parameterization (Rucker & Wensing
    2022). Replaces the removed ``dr.body_inertia`` /
    ``dr.body_iquat``.
  - ``dr.geom_size`` with automatic recomputation of ``geom_rbound``
    and ``geom_aabb`` for broadphase consistency.
  - ``dr.tendon_armature`` and ``dr.tendon_frictionloss``.
  - ``dr.body_quat``, ``dr.geom_quat``, and ``dr.site_quat`` with RPY
    perturbation composed onto the default quaternion.
  - Extensible ``Operation`` and ``Distribution`` types. Users can define
    custom operations and distributions as class instances and pass them
    anywhere a string is accepted. Built-in instances (``dr.abs``,
    ``dr.scale``, ``dr.add``, ``dr.uniform``, ``dr.log_uniform``,
    ``dr.gaussian``) are exported from the ``dr`` module.
  - ``dr.mat_rgba`` for per-world material color randomization. Tints
    the texture color, useful for randomizing appearance of textured
    surfaces. Material names are now supported in ``SceneEntityCfg``
    (``material_names``).
  - Fixed ``dr.effort_limits`` drifting on repeated randomization.
  - Fixed ``dr.body_com_offset`` not triggering ``set_const``.

- ``export-scene`` CLI script to export any task scene or asset_zoo entity
  (``g1``, ``go1``, ``yam``) to a directory or zip archive for inspection
  and debugging.

- ``yam_lift_cube_vision_env_cfg`` now randomizes cube color (``dr.geom_rgba``)
  on every reset when ``cam_type="rgb"``.

- The native viewer now reflects per-world DR changes to visual model fields
  on each reset. Geom appearance, body and site poses, camera parameters,
  and light positions are all synced from the GPU model before rendering.
  Inertia boxes (press ``I``) and camera frustums (press ``Q``) update
  correctly when the corresponding fields are randomized. See
  :doc:`randomization` for viewer-specific caveats.

- ``MaterialCfg.geom_names_expr`` for assigning materials to geoms by
  name pattern during ``edit_spec``.

- ``TerrainEntityCfg`` now exposes ``textures``, ``materials``, and
  ``lights`` as configurable fields (previously hardcoded). Set
  ``textures=()``, ``materials=()`` to use flat ``dr.geom_rgba``
  instead of the default checker texture.

- ``DebugVisualizer`` now supports ellipsoid visualization via
  ``add_ellipsoid``.

- Interactive velocity joystick sliders in the Viser viewer. Enable the
  joystick under Commands/Twist to override velocity commands with manual
  sliders for ``lin_vel_x``, ``lin_vel_y``, and ``ang_vel_z``
  (`#666 <https://github.com/mujocolab/mjlab/issues/666>`_).
- Per-term debug visualization toggles in the Viser viewer. Individual
  command term visualizers (e.g. velocity arrows) can now be toggled
  independently under Scene/Debug Viz.
- Viewer single-step mode: press RIGHT arrow (native) or click "Step"
  (Viser) to advance exactly one physics step while paused.
- Viewer error recovery: exceptions during stepping now pause the viewer
  and log the traceback instead of crashing the process.
- Native viewer runs forward kinematics while paused, keeping
  perturbation visuals accurate.
- Viewer speed multipliers use clean power-of-2 fractions (1/32x to 1x).

- Visualizers display the realtime factor alongside FPS.

- ``joint_torques_l2`` now respects ``SceneEntityCfg.actuator_ids``,
  allowing penalization of a subset of actuators instead of all of them
  (`#703 <https://github.com/mujocolab/mjlab/pull/703>`_). Contribution by
  `@saikishor <https://github.com/saikishor>`_.

- Terrain is now a proper ``Entity`` subclass (``TerrainEntity``). This
  allows domain randomization functions to target terrain parameters
  (friction, cameras, lights) via ``SceneEntityCfg("terrain", ...)``.
  ``TerrainImporter`` / ``TerrainImporterCfg`` remain as aliases but will be
  deprecated in a future version.
- Added ``upload_model`` option to ``RslRlBaseRunnerCfg`` to control W&B model
  file uploads (``.pt`` and ``.onnx``) while keeping metric logging enabled
  (`#654 <https://github.com/mujocolab/mjlab/pull/654>`_).
- ``Scene.write(output_dir, zip=False)`` exports the scene XML and mesh
  assets to a directory (or zip archive). Replaces ``Scene.to_zip()``.
- ``Entity.write_xml()`` and ``Scene.write()`` now apply XML fixups
  (empty defaults, duplicate nested defaults) and strip buffer textures
  that ``MjSpec.to_xml()`` cannot serialize.
- ``fix_spec_xml`` and ``strip_buffer_textures`` utilities in
  ``mjlab.utils.xml``.

Changed
^^^^^^^

- Native viewer now syncs ``xfrc_applied`` to the render buffer and draws
  arrows for any nonzero applied forces. Mouse perturbation forces are
  converted to ``qfrc_applied`` (generalized joint space) so they coexist
  with programmatic forces on ``xfrc_applied`` without conflict.
- ``ViewerConfig.OriginType.WORLD`` now configures a free camera at the
  specified lookat point instead of auto tracking a body. A new ``AUTO``
  origin type (now the default) preserves the previous auto tracking
  behavior.
- Upgraded ``rsl-rl-lib`` from 4.0.1 to 5.0.1. ``RslRlModelCfg`` now
  uses ``distribution_cfg`` dict instead of ``stochastic`` /
  ``init_noise_std`` / ``noise_std_type``. Existing checkpoints are
  automatically migrated on load.
- Reorganized the Viser Controls tab into a cleaner folder hierarchy:
  Info, Simulation, Commands, Scene (with Environment, Camera, Debug Viz,
  Contacts sub-folders), and Camera Feeds. The Environment folder is
  hidden for single-env tasks and the Commands folder is hidden when no
  command terms are active.
- Viser camera tracking is now enabled by default so the agent stays in
  frame on launch.
- Self collision and illegal contact sensors now use ``history_length`` to
  catch contacts across decimation substeps. Reward and termination functions
  read ``force_history`` with a configurable ``force_threshold``.
- Replaced the single ``scale`` parameter in ``DifferentialIKActionCfg`` with
  separate ``delta_pos_scale`` and ``delta_ori_scale`` for independent scaling
  of position and orientation components.
- Improved offscreen multi environment framing by selecting neighboring
  environments around the focused env instead of first N envs.
- Tuned tracking task viewer defaults for tighter camera framing.
- Disabled shadow casting on the G1 tracking light to avoid duplicate
  stacked shadows when robots are close.

Fixed
^^^^^

- Fixed actuator target resolution for entities whose ``spec_fn`` uses
  internal ``MjSpec.attach(prefix=...)``
  (`#709 <https://github.com/mujocolab/mjlab/issues/709>`_).
- Fixed viewer physics loop starving the renderer by replacing the single
  sim-time budget with a two-clock design (tracked vs actual sim time).
  Physics now self-corrects after overshooting, keeping FPS smooth at all
  speed multipliers.
- Bundled ``ffmpeg`` for ``mediapy`` via ``imageio-ffmpeg``, removing the
  requirement for a system ``ffmpeg`` install. Thanks to
  `@rdeits-bd <https://github.com/rdeits-bd>`_ for the suggestion.
- Fixed ``height_scan`` returning ~0 for missed rays; now defaults to
  ``max_distance``. Replaced ``clip=(-1, 1)`` with ``scale`` normalization
  in the velocity task config. Thanks to `@eufrizz <https://github.com/eufrizz>`_
  for reporting and the initial fix (`#642 <https://github.com/mujocolab/mjlab/pull/642>`_).
- Fixed ghost mesh visualization for fixed-base entities by extending
  ``DebugVisualizer.add_ghost_mesh`` to optionally accept ``mocap_pos`` and
  ``mocap_quat`` (`#645 <https://github.com/mujocolab/mjlab/pull/645>`_).
- Fixed viser viewer crashing on scenes with no mocap bodies by adding
  an ``nmocap`` guard, matching the native viewer behavior.
- Fixed offscreen rendering artifacts in large vectorized scenes by applying
  a render local extent override in ``OffscreenRenderer`` and restoring the
  original extent on close.
- Fixed ``RslRlVecEnvWrapper.unwrapped`` to return the base environment,
  ensuring checkpoint state restore and logging work correctly when wrappers
  such as ``VideoRecorder`` are enabled.

Version 1.1.1 (February 14, 2026)
---------------------------------

Added
^^^^^

- Added reward term visualization to the native viewer (toggle with ``P``) (`#629 <https://github.com/mujocolab/mjlab/pull/629>`_).
- Added ``DifferentialIKAction`` for task-space control via damped
  least-squares IK. Supports weighted position/orientation tracking,
  soft joint-limit avoidance, and null-space posture regularization.
  Includes an interactive viser demo (``scripts/demos/differential_ik.py``) (`#632 <https://github.com/mujocolab/mjlab/pull/632>`_).

Fixed
^^^^^

- Fixed ``play.py`` defaulting to the base rsl-rl ``OnPolicyRunner`` instead
  of ``MjlabOnPolicyRunner``, which caused a ``TypeError`` from an unexpected
  ``cnn_cfg`` keyword argument (`#626 <https://github.com/mujocolab/mjlab/pull/626>`_). Contribution by
  `@griffinaddison <https://github.com/griffinaddison>`_.

Changed
^^^^^^^

- Removed ``body_mass``, ``body_inertia``, ``body_pos``, and ``body_quat``
  from ``FIELD_SPECS`` in domain randomization. These fields have derived
  quantities that require ``set_const`` to recompute; without that call,
  randomizing them silently breaks physics (`#631 <https://github.com/mujocolab/mjlab/pull/631>`_).
- Replaced ``moviepy`` with ``mediapy`` for video recording. ``mediapy``
  handles cloud storage paths (GCS, S3) natively (`#637 <https://github.com/mujocolab/mjlab/pull/637>`_).

.. figure:: _static/changelog/native_reward.png
   :width: 80%

Version 1.1.0 (February 12, 2026)
---------------------------------

Added
^^^^^

- Added RGB and depth camera sensors and BVH-accelerated raycasting (`#597 <https://github.com/mujocolab/mjlab/pull/597>`_).
- Added ``MetricsManager`` for logging custom metrics during training (`#596 <https://github.com/mujocolab/mjlab/pull/596>`_).
- Added terrain visualizer (`#609 <https://github.com/mujocolab/mjlab/pull/609>`_). Contribution by
  `@mktk1117 <https://github.com/mktk1117>`_.

.. figure:: _static/changelog/terrain_visualizer.jpg
   :width: 80%

- Added many new terrains including ``HfDiscreteObstaclesTerrainCfg``,
  ``HfPerlinNoiseTerrainCfg``, ``BoxSteppingStonesTerrainCfg``,
  ``BoxNarrowBeamsTerrainCfg``, ``BoxRandomStairsTerrainCfg``, and
  more. Added flat patch sampling for heightfield terrains (`#542 <https://github.com/mujocolab/mjlab/pull/542>`_, `#581 <https://github.com/mujocolab/mjlab/pull/581>`_).
- Added site group visualization to the Viser viewer (Geoms and Sites
  tabs unified into a single Groups tab) (`#551 <https://github.com/mujocolab/mjlab/pull/551>`_).
- Added ``env_ids`` parameter to ``Entity.write_ctrl_to_sim`` (`#567 <https://github.com/mujocolab/mjlab/pull/567>`_).

Changed
^^^^^^^

- Upgraded ``rsl-rl-lib`` to 4.0.0 and replaced the custom ONNX
  exporter with rsl-rl's built-in ``as_onnx()`` (`#589 <https://github.com/mujocolab/mjlab/pull/589>`_, `#595 <https://github.com/mujocolab/mjlab/pull/595>`_).
- ``sim.forward()`` is now called unconditionally after the decimation
  loop. See :ref:`faq-sim-forward` for details (`#591 <https://github.com/mujocolab/mjlab/pull/591>`_).
- Unnamed freejoints are now automatically named to prevent
  ``KeyError`` during entity init (`#545 <https://github.com/mujocolab/mjlab/pull/545>`_).

Fixed
^^^^^

- Fixed ``randomize_pd_gains`` crash with ``num_envs > 1`` (`#564 <https://github.com/mujocolab/mjlab/pull/564>`_).
- Fixed ``ctrl_ids`` index error with multiple actuated entities (`#573 <https://github.com/mujocolab/mjlab/pull/573>`_).
  Reported by `@bwrooney82 <https://github.com/bwrooney82>`_.
- Fixed Viser viewer rendering textured robots as gray (`#544 <https://github.com/mujocolab/mjlab/pull/544>`_).
- Fixed Viser plane rendering ignoring MuJoCo size parameter (`#540 <https://github.com/mujocolab/mjlab/pull/540>`_).
- Fixed ``HfDiscreteObstaclesTerrainCfg`` spawn height (`#552 <https://github.com/mujocolab/mjlab/pull/552>`_).
- Fixed ``RaycastSensor`` visualization ignoring the all-envs toggle (`#607 <https://github.com/mujocolab/mjlab/pull/607>`_).
  Contribution by `@oxkitsune <https://github.com/oxkitsune>`_.

Version 1.0.0 (January 28, 2026)
--------------------------------

Initial release of mjlab.
